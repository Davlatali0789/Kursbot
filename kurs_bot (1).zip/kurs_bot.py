
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, InputMediaPhoto
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, CallbackQueryHandler, ContextTypes
import os, json

TOKEN = "7848546643:AAEkYGEnPtvjvQQ4bLhcxxUsgKK1CH6rPZY"
ADMIN_ID = 8159794716

# Kurs linklari
LINK_ODDIY = "https://t.me/+EW9BqcsMh0EwMzQy"
LINK_ORTACHA = "https://t.me/+vLQx4g0G8JA5YTdi"
LINK_KUCHLI = "https://t.me/+7geHMmZK3zllMjRi"

# Karta malumotlari
CARD_TEXT = (
    "\U0001F4B3 To‘lov uchun kartalar:\n"
    "\nUzCard/Humo: 9860 1678 4515 7392\n"
    "VISA: 4231 2000 1385 0457\n"
    "Egasining ismi: Davlatali Rustamaliyev\n"
    "\nTo‘lovdan so‘ng skrinshotni shu yerga yuboring."
)

# Foydalanuvchi tanlovi
user_courses = {}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Oddiy kurs – 30 000", callback_data="oddiy")],
        [InlineKeyboardButton("O‘rtacha kurs – 60 000", callback_data="ortacha")],
        [InlineKeyboardButton("Kuchli kurs – 120 000", callback_data="kuchli")],
    ]
    await update.message.reply_text(
        "Qaysi kursni tanlaysiz?", reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    kurs = query.data
    user_courses[user_id] = kurs

    await query.message.reply_text(CARD_TEXT)

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_id = user.id
    kurs = user_courses.get(user_id, "nomalum")
    caption = f"🧾 <b>Yangi to‘lov!</b>\n👤 @{user.username or user.first_name}\n🆔 <code>{user_id}</code>\n🎓 Kurs: <b>{kurs.title()}</b>"

    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Tasdiqlash", callback_data=f"tasdiq:{user_id}:{kurs}")]
    ])
    photo_file_id = update.message.photo[-1].file_id

    await context.bot.send_photo(
        chat_id=ADMIN_ID,
        photo=photo_file_id,
        caption=caption,
        reply_markup=keyboard,
        parse_mode="HTML"
    )

async def tasdiqla(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data.split(":")
    user_id, kurs = int(data[1]), data[2]

    link = {
        "oddiy": LINK_ODDIY,
        "ortacha": LINK_ORTACHA,
        "kuchli": LINK_KUCHLI,
    }.get(kurs, None)

    if link:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"✅ To‘lov tasdiqlandi! Mana kurs linki: {link}"
        )
        await query.edit_message_caption(caption="☑️ Tasdiqlandi va link yuborildi")
    else:
        await query.edit_message_caption(caption="❌ Kurs linki topilmadi")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CallbackQueryHandler(button, pattern="^(oddiy|ortacha|kuchli)$"))
app.add_handler(CallbackQueryHandler(tasdiqla, pattern="^tasdiq:"))
app.add_handler(MessageHandler(filters.PHOTO, handle_photo))

print("🤖 Bot ishga tushdi")
app.run_polling()
